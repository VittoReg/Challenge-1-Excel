This is Vittorio Regalbuto's assignment.

NOTE:

When I was to the point where the exercise asks you to split the "Category & Sub-Category" column into 2 new ones (Parent Category & Sub-Category)
therefore I applied the formula
=TEXTSPLIT(R2:R1001,"/")
the issue I had is that the outcome is only pasting what is before the "/" into the column where I typed the formula
I believe it should automatically past what is after the "/" into the next column to the right, however this is not happening
I have solved this issue by using the textsplit wizard, however I'm aware that the exercise is asking for a formula to be used.

Therefore I wanted to flag this up, in case you click on the cell and realise that there is no formula, just so you know that I did not type it in manually :)

Thank you